package com.nttdata.docto.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.nttdata.docto.dao.DoctorRepository;
import com.nttdata.docto.dao.SpecializationRepository;
import com.nttdata.docto.dao.UserRepository;
import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;
import com.nttdata.docto.entity.User;




@Controller
public class DoctoController {
	
	@Autowired
	private UserRepository userService;
	
	@Autowired
	private DoctorRepository doctorRep;
	
	@Autowired
	private SpecializationRepository specRep;
	
	@RequestMapping("/")
    public String index() {
        return "index.jsp";
    }
	@RequestMapping("/home")
    public String home() {
        return "index.jsp";
    }
	@RequestMapping("/doctor")
    public String doctor() {
        return "doctor.jsp";
    }
	@RequestMapping("/about")
    public String about() {
        return "about.jsp";
    }
	@RequestMapping("/contact")
    public String contact() {
        return "contact.jsp";
    }
	@RequestMapping("/login")
    public String login() {
        return "login.jsp";
    }
	
	@RequestMapping(value ="/search",method = RequestMethod.GET)
	public String newRegistration(ModelMap model) {
		Doctor doctor=new Doctor();
		/*System.out.println(doctorRep.findAREA());
		System.out.println(specRep.findAllSpecsWithJpql());*/
		model.addAttribute("area", doctorRep.findAREA());
		model.addAttribute("specval",specRep.findAllSpecsWithJpql());
		model.addAttribute("doctor",doctor);
		
		return "search.jsp";
	}
	
	@RequestMapping(value ="/search",method = RequestMethod.POST)
	public ModelAndView saveRegistration(@ModelAttribute Doctor doctor,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		System.out.println(doctor.getDoctorArea());
		System.out.println(doctor.getSpec());
		//List<Doctor> list= doctoService.getStudentsByLocSpec(doctor.getSpec().getSpecId(),doctor.getDoctorArea());
		List<Doctor> list= doctorRep.findDoctorByAreaAndSpec(doctor.getSpec().getSpecId(),doctor.getDoctorArea());
		System.out.println(list);
		return new ModelAndView("viewdoctor.jsp","list",list); 
	
	}
	
	@RequestMapping(value ="/usersave",method = RequestMethod.GET)
	public String newUserRegistration(ModelMap model) {
		User user=new User();
		model.addAttribute("user", user);
		return "userReg.jsp";
	}
	
	@RequestMapping(value ="/usersave",method = RequestMethod.POST)
	public String saveRegistration(@Valid User user,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		user.setUserId(5);
		if (result.hasErrors()) {
			return "userReg.jsp";//will redirect to viewemp request mapping  
		}
		userService.save(user);		
		
		return "redirect:/login";//will redirect to viewemp request mapping  
	}
	
	// doctor registration
	@RequestMapping(value ="/doctorsave",method = RequestMethod.GET)
	public String newDoctorRegistration(ModelMap model) {
		Doctor doctor=new Doctor();
		model.addAttribute("specval",specRep.findAllSpecsWithJpql());
		model.addAttribute("doctor", doctor);
		return "DoctorRegister.jsp";
	}
	
	@RequestMapping(value ="/doctorsave",method = RequestMethod.POST)
	public String saveDoctorRegistration(@ModelAttribute Doctor doctor,
		BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		System.out.println(doctor.getSpec());
		System.out.println(doctor);
		if (result.hasErrors()) {
			return "DoctorRegister.jsp";//will redirect to viewemp request mapping  
		}
		
		doctorRep.save(doctor);		
		//redirectAttributes.addFlashAttribute("message", "Student " + student.getFirstName()+" "+student.getLastName() + " saved");
		return "redirect:/login";//will redirect to viewemp request mapping  
	}

	
	
	@ModelAttribute("countries")
	public List<String> initializeCountries() {

		List<String> countries = new ArrayList<String>();
		countries.add("INDIA");
		countries.add("USA");
		countries.add("CANADA");
		countries.add("FRANCE");
		countries.add("GERMANY");
		countries.add("ITALY");
		countries.add("OTHER");
		return countries;
	}
	
	@RequestMapping("/signin")
	public String loginPage()
	{
		return "signin.jsp";
	}
	
	@RequestMapping("/logout-success")
	public String logoutPage()
	{
		return "logout.jsp";
	}
	
	

}

package com.nttdata.docto.security;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nttdata.docto.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {

	User findByEmail(String email);

}

package com.nttdata.docto.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.service.DoctoService;



@Controller
public class DoctoController {
	
	@Autowired
	private DoctoService doctoService;
	
	@RequestMapping("/")
    public String index() {
        return "index.jsp";
    }
	@RequestMapping("/home")
    public String home() {
        return "index.jsp";
    }
	@RequestMapping("/doctor")
    public String doctor() {
        return "doctor.jsp";
    }
	@RequestMapping("/about")
    public String about() {
        return "about.jsp";
    }
	@RequestMapping("/contact")
    public String contact() {
        return "contact.jsp";
    }
	@RequestMapping("/login")
    public String login() {
        return "login.jsp";
    }
	
	@RequestMapping(value ="/find",method = RequestMethod.GET)
	public String newRegistration(ModelMap model) {
		Doctor doctor=new Doctor();
		model.addAttribute("doctor",doctor);
		return "search.jsp";
	}
	
	@RequestMapping(value ="/search",method = RequestMethod.POST)
	public ModelAndView saveRegistration(Doctor doctor,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		//System.out.println(doctor.getArea());
		List<Doctor> list= doctoService.getStudentsByLocSpec(doctor.getSpecialization(), doctor.getArea());
	
		return new ModelAndView("viewdoctor.jsp","list",list); 
	
	}
	
	

}

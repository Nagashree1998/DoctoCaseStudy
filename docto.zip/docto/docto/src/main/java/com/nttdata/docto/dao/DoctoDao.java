package com.nttdata.docto.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;


import com.nttdata.docto.entity.Doctor;

@Service
public class DoctoDao implements IDoctoDao{

	JdbcTemplate template; 
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new JdbcTemplate(dataSource);
	}
	
	
	
	@Override
	public List<Doctor> getStudentsByLocSpec(String specialization, String location) {
		return (List<Doctor>) template.query("select * from doctor where specialization='"+specialization+"' and area_name='"+location+"'",new ResultSetExtractor<List<Doctor>>(){  
		    
	     public List<Doctor> extractData(ResultSet rs) throws SQLException,  
	            DataAccessException {  
	      
	    	 
	    	 
	    	 List<Doctor> list=new ArrayList<Doctor>();
	    
	        while(rs.next()){ 
	        	Doctor e=new Doctor();  
	        	System.out.println(rs.getInt(1));
	        	e.setDoctorId(rs.getInt(1));
	        	e.setDoctorName(rs.getString(2));
	        	e.setAge(rs.getInt(3));
	        	e.setSpecialization(rs.getString(4));
	        	e.setContact(rs.getInt(5));
	        	e.setArea(rs.getString(6));
	        	e.setLocation(rs.getString(7));
	        	
	        	list.add(e);
	        	//System.out.println(e);
		        
	        }  
	        System.out.println(list);
	        return list;  
	        }  
	    });  
			
		
	}
	

}

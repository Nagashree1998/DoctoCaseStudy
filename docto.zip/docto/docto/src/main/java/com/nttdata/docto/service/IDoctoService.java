package com.nttdata.docto.service;

import java.util.List;

import com.nttdata.docto.entity.Doctor;



public interface IDoctoService {

	public List<Doctor> getStudentsByLocSpec(String specialization, String location);
}

package com.nttdata.docto.entity;

import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Doctor {

	@Id
	private int doctorId;
	
	@NotEmpty
	private String doctorName;
	
	@NotEmpty
	private String specialization;
	
	private int age;


	@NotEmpty
	private int contact;
	
	@NotEmpty
	private String area;
	
	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@NotEmpty
	private String location;

	@Override
	public String toString() {
		return String.format(
				"Doctor [doctorId=%s, doctorName=%s, specialization=%s, age=%s, contact=%s, area=%s, location=%s]",
				doctorId, doctorName, specialization, age, contact, area, location);
	}

	
}

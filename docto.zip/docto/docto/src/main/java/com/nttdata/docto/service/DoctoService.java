package com.nttdata.docto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.docto.dao.DoctoDao;
import com.nttdata.docto.entity.Doctor;

@Service
public class DoctoService implements IDoctoService{

	@Autowired
	DoctoDao doctoDao;
	
	@Override
	public List<Doctor> getStudentsByLocSpec(String specialization, String location) {
		
		return doctoDao.getStudentsByLocSpec(specialization, location);
	}

}

package com.nttdata.docto.entity;


import javax.persistence.*;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@SequenceGenerator(name="doc", initialValue=1, allocationSize=1)
public class Doctor {
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="doc")
		private int doctorId;
		
		@NotEmpty
		@Column(nullable=false)
		private String doctorName;
		
		@Column 
		private String doctorEmail;
		
		@Column
		private String doctorPassword;
		
		
		@Column
		private int doctorAge;
		
		@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.MERGE)
	    @JoinColumn(name = "Spec_id")
		private Specialization spec;

		@Column
		private long doctorContact;
		
		@Column
		private String doctorArea;
		
		@Column
		private String doctorLocation;


		public Doctor() {
			// TODO Auto-generated constructor stub
		}

		public int getDoctorId() {
			return doctorId;
		}

		public void setDoctorId(int doctorId) {
			this.doctorId = doctorId;
		}

		public String getDoctorName() {
			return doctorName;
		}

		public void setDoctorName(String doctorName) {
			this.doctorName = doctorName;
		}

		public int getDoctorAge() {
			return doctorAge;
		}

		public void setDoctorAge(int doctorAge) {
			this.doctorAge = doctorAge;
		}

		public Specialization getSpec() {
			return spec;
		}

		public void setSpec(Specialization spec) {
			this.spec = spec;
		}

		public long getDoctorContact() {
			return doctorContact;
		}

		public void setDoctorContact(long doctorContact) {
			this.doctorContact = doctorContact;
		}

		public String getDoctorArea() {
			return doctorArea;
		}

		public void setDoctorArea(String doctorArea) {
			this.doctorArea = doctorArea;
		}

		public String getDoctorLocation() {
			return doctorLocation;
		}

		public void setDoctorLocation(String doctorLocation) {
			this.doctorLocation = doctorLocation;
		}

		@Override
		public String toString() {
			return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorAge=" + doctorAge
					+ ", spec=" + spec + ", doctorContact=" + doctorContact + ", doctorArea=" + doctorArea
					+ ", doctorLocation=" + doctorLocation + "]";
		}

		public Doctor(int doctorId, @NotEmpty String doctorName, String email, String password, int doctorAge,
				Specialization spec, long doctorContact, String doctorArea, String doctorLocation) {
			super();
			this.doctorId = doctorId;
			this.doctorName = doctorName;
			this.doctorEmail = email;
			this.doctorPassword = password;
			this.doctorAge = doctorAge;
			this.spec = spec;
			this.doctorContact = doctorContact;
			this.doctorArea = doctorArea;
			this.doctorLocation = doctorLocation;
		}

	
		
		
		
	
}
	
	
	   
	 
	

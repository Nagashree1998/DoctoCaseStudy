package com.nttdata.docto.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@SequenceGenerator(name="spec", initialValue=24, allocationSize=1)
public class Specialization {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="spec")
	private Long specId;
	@Column
	private String specName;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<Doctor> doctor;
	public long getSpecId() {
		return specId;
	}
	public void setSpecId(long specId) {
		this.specId = specId;
	}
	public String getSpecName() {
		return specName;
	}
	public void setSpecName(String specName) {
		this.specName = specName;
	}
	public List<Doctor> getDoctor() {
		return doctor;
	}
	public void addDoctor(Doctor doctor) {
		this.doctor.add(doctor);
	}
	public Specialization(long specId, String specName) {
		super();
		this.specId = specId;
		this.specName = specName;
	}
	@Override
	public String toString() {
		return "Specialization [specId=" + specId + ", specName=" + specName+"]" ;
	}
	public Specialization() {
		
	}
	public Specialization(long specId) {
		super();
		this.specId = specId;
	}
	
	
	

	

}

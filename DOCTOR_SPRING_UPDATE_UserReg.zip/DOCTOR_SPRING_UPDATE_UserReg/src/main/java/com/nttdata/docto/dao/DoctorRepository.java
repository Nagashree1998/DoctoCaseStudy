package com.nttdata.docto.dao;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;


@Repository
@Transactional
public class DoctorRepository  {
	@Autowired
	EntityManager em;
	
	public Doctor save(Doctor doctor){
		 if(doctor.getDoctorId()==0){
			 em.persist(doctor);
		 }
		 else{
			 em.merge(doctor);
		 }
		 return doctor;
	 }
	
}

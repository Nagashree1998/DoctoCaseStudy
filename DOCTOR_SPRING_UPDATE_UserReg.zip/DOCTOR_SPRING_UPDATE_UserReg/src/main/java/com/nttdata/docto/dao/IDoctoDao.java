package com.nttdata.docto.dao;

import java.util.List;

import com.nttdata.docto.entity.Doctor;

public interface IDoctoDao {

	public List<Doctor> getStudentsByLocSpec(long specialization, String location);
}

 Insert into specialization (spec_id,spec_name) values ('20','derma');
 Insert into specialization (spec_id,spec_name) values ('21','syco');
 Insert into specialization (spec_id,spec_name) values ('22','dental');



package com.nttdata.docto;

import java.util.Scanner;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;
import com.nttdata.docto.repository.DoctorRepository;
import com.nttdata.docto.repository.SpecializationRepository;

@SpringBootApplication
@EnableJpaAuditing
public class DoctoApplication {
	/*@Autowired
    DataSource dataSource;
	
    @Autowired
    DoctorRepository doctorRepository;
    

    
	
    Scanner scan =new Scanner(System.in);*/
    @Autowired
     SpecializationRepository SpecRepository;
	public static void main(String[] args) {
		
		SpringApplication.run(DoctoApplication.class, args);
		System.out.println("Started");
		
	}
	/*@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(SpecRepository.findAllSpecsWithJpql());
	}*/

	

    

}




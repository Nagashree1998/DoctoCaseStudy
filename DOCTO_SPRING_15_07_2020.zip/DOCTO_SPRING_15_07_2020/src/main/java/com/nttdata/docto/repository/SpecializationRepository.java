package com.nttdata.docto.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;

@Repository
@Transactional
public class SpecializationRepository {
	@Autowired
	EntityManager em;
	
	public List<Specialization> findAllSpecsWithJpql() {
	    return em.createQuery("select a from Specialization a", Specialization.class).getResultList();    

	}
	
	public Specialization save(Specialization spec){
		 if(spec.getSpecId()==0){
			 em.persist(spec);
		 }
		 else{
			 em.merge(spec);
		 }
		 return spec;
	 }
	public Specialization findById(Long id){
		Specialization spec=em.find(Specialization.class, id);
		return spec;
		}
	
	

}

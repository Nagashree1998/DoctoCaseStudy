package com.nttdata.docto.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.User;

@Repository
@Transactional
public class UserRepository {
	
	@Autowired
	EntityManager em;
	
	public User save(User user){
		 if(user.getUserId()==0){
			 em.persist(user);
		 }
		 else{
			 em.merge(user);
		 }
		 return user;
	 }
	
	public List<User> validateUser(String email,String password){
		Query query = em.createQuery("select e from User e where e.email='"+email+"' and e.password='"+password+"'");
		List<User> resultList = query.getResultList();
		System.out.println("login "+resultList);
		return resultList;
	}
}

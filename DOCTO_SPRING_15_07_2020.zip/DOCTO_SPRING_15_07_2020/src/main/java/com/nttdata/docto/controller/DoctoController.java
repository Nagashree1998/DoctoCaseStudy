package com.nttdata.docto.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nttdata.docto.entity.Availability;
import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;
import com.nttdata.docto.entity.User;
import com.nttdata.docto.repository.AvailabilityRepository;
import com.nttdata.docto.repository.DoctorRepository;
import com.nttdata.docto.repository.SpecializationRepository;
import com.nttdata.docto.repository.UserRepository;




@Controller
public class DoctoController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private DoctorRepository doctorRep;
	
	@Autowired
	private AvailabilityRepository availRepository;
	
	@Autowired
	private SpecializationRepository specRep;
	
	@RequestMapping("/")
    public String index() {
        return "index.jsp";
    }
	@RequestMapping("/home")
    public String home() {
        return "index.jsp";
    }
	@RequestMapping("/doctor")
    public String doctor() {
        return "doctor.jsp";
    }
	@RequestMapping("/about")
    public String about() {
        return "about.jsp";
    }
	@RequestMapping("/contact")
    public String contact() {
        return "contact.jsp";
    }
	
	
	@RequestMapping(value ="/search",method = RequestMethod.GET)
	public String newRegistration(ModelMap model) {
		Doctor doctor=new Doctor();
		model.addAttribute("area", doctorRep.findAREA());
		model.addAttribute("specval",specRep.findAllSpecsWithJpql());
		model.addAttribute("doctor",doctor);
		
		return "search.jsp";
	}
	
	@RequestMapping(value ="/search",method = RequestMethod.POST)
	public ModelAndView saveRegistration(@ModelAttribute Doctor doctor,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		System.out.println(doctor.getDoctorArea());
		System.out.println(doctor.getSpec());
		List<Doctor> list= doctorRep.findDoctorByAreaAndSpec(doctor.getSpec().getSpecId(),doctor.getDoctorArea());
		System.out.println(list);
		return new ModelAndView("viewdoctor.jsp","list",list); 
	
	}
	
	@RequestMapping(value ="/usersave",method = RequestMethod.GET)
	public String newUserRegistration(ModelMap model) {
		User user=new User();
		model.addAttribute("user", user);
		return "userReg.jsp";
	}
	
	@RequestMapping(value ="/usersave",method = RequestMethod.POST)
	public String saveRegistration(@Valid User user,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		user.setUserId(5);
		if (result.hasErrors()) {
			return "userReg.jsp";  
		}
		userRepository.save(user);		
		
		return "redirect:/signin";  
	}
	
	// doctor registration
	@RequestMapping(value ="/doctorsave",method = RequestMethod.GET)
	public String newDoctorRegistration(ModelMap model) {
		Doctor doctor=new Doctor();
		model.addAttribute("specval",specRep.findAllSpecsWithJpql());
		model.addAttribute("doctor", doctor);
		return "DoctorRegister.jsp";
	}
	
	@RequestMapping(value ="/doctorsave",method = RequestMethod.POST)
	public String saveDoctorRegistration(@ModelAttribute Doctor doctor,
		BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		System.out.println(doctor.getSpec());
		System.out.println(doctor);
		if (result.hasErrors()) {
			return "DoctorRegister.jsp";  
		}
		
		doctorRep.save(doctor);		
		return "redirect:/signin";
	}

	
	
	@ModelAttribute("countries")
	public List<String> initializeCountries() {

		List<String> countries = new ArrayList<String>();
		countries.add("INDIA");
		countries.add("USA");
		countries.add("CANADA");
		countries.add("FRANCE");
		countries.add("GERMANY");
		countries.add("ITALY");
		countries.add("OTHER");
		return countries;
	}
	
	@ModelAttribute("availTimes")
	public List availTime() {

		List availTimes = new ArrayList();
		/*for(int i=1;i<=22;i++)
		{
		availTimes.add(i);
		}*/
		availTimes.add(1);
		availTimes.add(3);
		availTimes.add(2);
		availTimes.add(5);
		return availTimes;
		
	}
	
	@RequestMapping("/logout-success")
	public String logoutPage()
	{
		return "logout.jsp";
	}
	
	
	@RequestMapping(value ="/userlogin",method = RequestMethod.GET)
	public String userlogin(ModelMap model) {
		User user= new User();
		/*System.out.println(doctorRep.findAREA());
		System.out.println(specRep.findAllSpecsWithJpql());*/
		/*model.addAttribute("area", doctorRep.findAREA());
		model.addAttribute("specval",specRep.findAllSpecsWithJpql());*/
		model.addAttribute("user",user);
		
		return "usersignin.jsp";
	}
	
	@RequestMapping(value ="/userlogin",method = RequestMethod.POST)
	public ModelAndView validateuserlogin(@ModelAttribute User user,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
		/*System.out.println(doctor.getDoctorArea());
		System.out.println(doctor.getSpec());*/
		//List<Doctor> list= doctoService.getStudentsByLocSpec(doctor.getSpec().getSpecId(),doctor.getDoctorArea());
		/*System.out.print(user.getEmail());
		System.out.print(user.getPassword());*/
		List<User> list= userRepository.validateUser(user.getEmail(),user.getPassword());
		//System.out.println(list);
		String msg="Invalid Credentials";
		if(!(list.isEmpty())){
			return new ModelAndView("UserHome.jsp","list",list);
		}
		else{
			return new ModelAndView("usersignin.jsp","msg",msg);
		}
	
	}
	
	@RequestMapping(value ="/doctorlogin",method = RequestMethod.GET)
    public String doctorlogin(ModelMap model) {
        Doctor doctor= new Doctor();
        model.addAttribute("doctor",doctor);
      
        return "doctorsignin.jsp";
    }
  
    @RequestMapping(value ="/doctorlogin",method = RequestMethod.POST)
    public ModelAndView validatedoctorlogin(@ModelAttribute Doctor doctor,
            BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
        List<Doctor> list= doctorRep.validateDoctor(doctor.getDoctorEmail(),doctor.getDoctorPassword());
       System.out.println(list);
       /*Calendar cal = Calendar.getInstance(); // locale-specific
       cal.setTime(new Date());
       cal.set(Calendar.HOUR_OF_DAY, 0);
       cal.set(Calendar.MINUTE, 0);
       cal.set(Calendar.SECOND, 0);
       cal.set(Calendar.MILLISECOND, 0);
       long time = cal.getT*/
       Date time= new Date();
       System.out.println(time+"........"+time.getHours()+":"+time.getMinutes());
        String msg="Invalid Credentials";
        if(!(list.isEmpty())){
            return new ModelAndView("DoctorHome.jsp","list",list);
        }
        else{
            return new ModelAndView("doctorsignin.jsp","msg",msg);
        }
  
    }
	
    /*@RequestMapping(value ="/updateavail",method = RequestMethod.GET)
    public String updateAvailability(ModelMap model) {
        Availability availability=new Availability();
        model.addAttribute("availability",availability);
      
        return "UpdateAvailability.jsp";
    }
  
    @RequestMapping(value ="/updateavailble",method = RequestMethod.POST)
    public String updateAvailability(@ModelAttribute Availability availability,
            BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {
    	Doctor doctor=(Doctor) doctorRep.findById(2);
        availability.setDoctor(doctor);
        System.out.print(doctor);
    	if (result.hasErrors()) {
			return "UpdateAvailability.jsp";  
		}
		
    	availRepository.save(availability);	
		return "DoctorHome.jsp";
       
    }*/
	
	

}

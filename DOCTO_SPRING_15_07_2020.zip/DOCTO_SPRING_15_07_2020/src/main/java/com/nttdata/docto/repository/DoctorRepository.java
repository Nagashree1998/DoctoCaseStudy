package com.nttdata.docto.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;


@Repository
@Transactional
public class DoctorRepository  {
	@Autowired
	EntityManager em;
	
	public Doctor save(Doctor doctor){
		 if(doctor.getDoctorId()==0){
			 em.persist(doctor);
		 }
		 else{
			 em.merge(doctor);
		 }
		 return doctor;
	 }
	public List<Doctor> findAREA(){
		return em.createQuery("select e from Doctor e",Doctor.class).getResultList();
	}
	
	public List<Doctor> findDoctorByAreaAndSpec(long specialization, String location){
		Query query = em.createQuery("select e from Doctor e where e.spec.specId='"+specialization+"' and e.doctorArea='"+location+"'");
		List<Doctor> resultList = query.getResultList();
		System.out.println("filter "+resultList);
		return resultList;
	}
	
	public List<Doctor> validateDoctor(String email,String password){
        Query query = em.createQuery("select d from Doctor d where d.doctorEmail='"+email+"' and d.doctorPassword='"+password+"'");
        List<Doctor> resultList = query.getResultList();
        //System.out.println("login "+resultList);
        return resultList;
	}
	
	public List<Doctor> findById(int doctorId){
		return em.createQuery("select e from Doctor e where e.doctorId="+doctorId,Doctor.class).getResultList();
	}
}

package com.nttdata.docto.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="Avail", initialValue=1001, allocationSize=1)
public class Availability {
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Avail")
		private int availabilityId;
		
		@Column
		private Date availabilityDate;
		
		@Column
		private Date availabilityStartTime;
		
		@Column
		private Date availabilityEndTime;
		
		@OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.MERGE)
		@JoinColumn(name = "doctorId")
		private Doctor doctor;

		public Availability() {
			super();
		}

		public Availability(int availabilityId, Date availabilityDate, Date availabilityStartTime,
				Date availabilityEndTime, Doctor doctor) {
			super();
			this.availabilityId = availabilityId;
			this.availabilityDate = availabilityDate;
			this.availabilityStartTime = availabilityStartTime;
			this.availabilityEndTime = availabilityEndTime;
			this.doctor = doctor;
		}

		@Override
		public String toString() {
			return "Availability [availabilityId=" + availabilityId + ", availabilityDate=" + availabilityDate
					+ ", availabilityStartTime=" + availabilityStartTime + ", availabilityEndTime="
					+ availabilityEndTime + ", doctor=" + doctor + "]";
		}

		public int getAvailabilityId() {
			return availabilityId;
		}

		public void setAvailabilityId(int availabilityId) {
			this.availabilityId = availabilityId;
		}

		public Date getAvailabilityDate() {
			return availabilityDate;
		}

		public void setAvailabilityDate(Date availabilityDate) {
			this.availabilityDate = availabilityDate;
		}

		public Date getAvailabilityStartTime() {
			return availabilityStartTime;
		}

		public void setAvailabilityStartTime(Date availabilityStartTime) {
			this.availabilityStartTime = availabilityStartTime;
		}

		public Date getAvailabilityEndTime() {
			return availabilityEndTime;
		}

		public void setAvailabilityEndTime(Date availabilityEndTime) {
			this.availabilityEndTime = availabilityEndTime;
		}

		public Doctor getDoctor() {
			return doctor;
		}

		public void setDoctor(Doctor doctor) {
			this.doctor = doctor;
		}
		
		
		
	
}

package com.nttdata.docto.repository;

import javax.persistence.EntityManager;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nttdata.docto.entity.Availability;


@Repository
@Transactional
public class AvailabilityRepository {

	@Autowired
	EntityManager em;
	
	public Availability save(Availability availability){
		 if(availability.getAvailabilityId()==0){
			 em.persist(availability);
		 }
		 else{
			 em.merge(availability);
		 }
		 return availability;
	 }
}
